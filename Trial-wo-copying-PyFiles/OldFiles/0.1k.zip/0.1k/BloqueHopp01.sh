#!/bin/bash -l
#SBATCH -D /data3/mantilla/AdditionalDataforOldData/A0.01/D2/0.1k
#SBATCH --partition=medium
#SBATCH --job-name=A0.01D2uN001BH01
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --mem-per-cpu=1G
#SBATCH --time=1-18:40:00

#SBATCH --output BloqueHopp01.out

python2.7 BloqueHopp01.py
