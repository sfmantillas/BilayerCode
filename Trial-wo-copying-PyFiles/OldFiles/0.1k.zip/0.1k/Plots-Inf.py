import numpy as np
import matplotlib.pyplot as plt
import scipy.interpolate as ipl
Parameters = np.genfromtxt('Parameters.txt')

data001 = np.genfromtxt('./Inf/ExtOC0.1k.txt')
MomentumAx001 = data001[:,][:,0]
OptConduct001 = data001[:,][:,1]

data002 = np.genfromtxt('./Inf/ExtOC0.2k.txt')
MomentumAx002 = data002[:,][:,0]
OptConduct002 = data002[:,][:,1]

data003 = np.genfromtxt('./Inf/ExtOC0.3k.txt')
MomentumAx003 = data003[:,][:,0]
OptConduct003 = data003[:,][:,1]

data004 = np.genfromtxt('./Inf/ExtOC0.4k.txt')
MomentumAx004 = data004[:,][:,0]
OptConduct004 = data004[:,][:,1]

data005 = np.genfromtxt('./Inf/ExtOC0.5k.txt')
MomentumAx005 = data005[:,][:,0]
OptConduct005 = data005[:,][:,1]

data006 = np.genfromtxt('./Inf/ExtOC0.6k.txt')
MomentumAx006 = data006[:,][:,0]
OptConduct006 = data006[:,][:,1]

data007 = np.genfromtxt('./Inf/ExtOC0.7k.txt')
MomentumAx007 = data007[:,][:,0]
OptConduct007 = data007[:,][:,1]

data008 = np.genfromtxt('./Inf/ExtOC0.8k.txt')
MomentumAx008 = data008[:,][:,0]
OptConduct008 = data008[:,][:,1]

data009 = np.genfromtxt('./Inf/ExtOC0.9k.txt')
MomentumAx009 = data009[:,][:,0]
OptConduct009 = data009[:,][:,1]

data010 = np.genfromtxt('./Inf/ExtOC1.0k.txt')
MomentumAx010 = data010[:,][:,0]
OptConduct010 = data010[:,][:,1]

data015 = np.genfromtxt('./Inf/ExtOC1.5k.txt')
MomentumAx015 = data015[:,][:,0]
OptConduct015 = data015[:,][:,1]

data020 = np.genfromtxt('./Inf/ExtOC2.0k.txt')
MomentumAx020 = data020[:,][:,0]
OptConduct020 = data020[:,][:,1]

data025 = np.genfromtxt('./Inf/ExtOC2.5k.txt')
MomentumAx025 = data025[:,][:,0]
OptConduct025 = data025[:,][:,1]

data030 = np.genfromtxt('./Inf/ExtOC3.0k.txt')
MomentumAx030 = data030[:,][:,0]
OptConduct030 = data030[:,][:,1]

data035 = np.genfromtxt('./Inf/ExtOC3.5k.txt')
MomentumAx035 = data035[:,][:,0]
OptConduct035 = data035[:,][:,1]

data040 = np.genfromtxt('./Inf/ExtOC4.0k.txt')
MomentumAx040 = data040[:,][:,0]
OptConduct040 = data040[:,][:,1]

data045 = np.genfromtxt('./Inf/ExtOC4.5k.txt')
MomentumAx045 = data045[:,][:,0]
OptConduct045 = data045[:,][:,1]

data050 = np.genfromtxt('./Inf/ExtOC5.0k.txt')
MomentumAx050 = data050[:,][:,0]
OptConduct050 = data050[:,][:,1]

data060 = np.genfromtxt('./Inf/ExtOC6.0k.txt')
MomentumAx060 = data060[:,][:,0]
OptConduct060 = data060[:,][:,1]
'''
data070 = np.genfromtxt('./Inf/ExtOC7.0k.txt')
MomentumAx070 = data070[:,][:,0]
OptConduct070 = data070[:,][:,1]

data080 = np.genfromtxt('./Inf/ExtOC8.0k.txt')
MomentumAx080 = data080[:,][:,0]
OptConduct080 = data080[:,][:,3]

data090 = np.genfromtxt('./Inf/ExtOC9.0k.txt')
MomentumAx090 = data090[:,][:,0]
OptConduct090 = data090[:,][:,3]

data100 = np.genfromtxt('OC10k.txt')
MomentumAx100 = data100[:,][:,0]
OptConduct100 = data100[:,][:,3]

dataInf = np.genfromtxt('./Inf/ExtOCInf.txt')
MomentumAxInf = dataInf[:,][:,0]
OptConductInf = dataInf[:,][:,1]

dataInf050 = np.genfromtxt('A0.2IntOC6.0k.txt')
MomentumAxInf050 = dataInf050[:,][:,0]
OptConductInf050 = dataInf050[:,][:,1]
'''

ReferenceP = np.zeros(len(MomentumAx100))
Reference0 = np.zeros(len(MomentumAx100))
ReferenceM = np.zeros(len(MomentumAx100))
for m1 in range(0,len(MomentumAx100)):
    ReferenceP[m1] = +(19-6*np.pi)/12.*Parameters[1]
    ReferenceM[m1] = +(19-6*np.pi)/12.*0.2

plt.semilogx(MomentumAx001,OptConduct001,'-',c=[1.0, 0.0, 0.0],label='$\\mathrm{0.1k}$',markersize=10.5*2)
plt.semilogx(MomentumAx002,OptConduct002,'-',c=[1.0, .25, 0.0],label='$\\mathrm{0.2k}$',markersize=9.5*2)
plt.semilogx(MomentumAx003,OptConduct003,'-',c=[1.0, .50, 0.0],label='$\\mathrm{0.3k}$',markersize=9.*2)
plt.semilogx(MomentumAx004,OptConduct004,'-',c=[1.0, .75, 0.0],label='$\\mathrm{0.4k}$',markersize=8.5*2)
plt.semilogx(MomentumAx005,OptConduct005,'-',c=[1.0, 1.0, 0.0],label='$\\mathrm{0.5k}$',markersize=9.*2)
plt.semilogx(MomentumAx006,OptConduct006,'-',c=[.75, 1.0, 0.0],label='$\\mathrm{0.6k}$',markersize=7.5*2)
plt.semilogx(MomentumAx007,OptConduct007,'-',c=[.50, 1.0, 0.0],label='$\\mathrm{0.7k}$',markersize=7.*2)
plt.semilogx(MomentumAx008,OptConduct008,'-',c=[.25, 1.0, 0.0],label='$\\mathrm{0.8k}$',markersize=6.5*2)
plt.semilogx(MomentumAx009,OptConduct009,'-',c=[0.0, 1.0, 0.0],label='$\\mathrm{0.9k}$',markersize=6.*2)
plt.semilogx(MomentumAx010,OptConduct010,'-',c=[0.0, 1.0, .25],label='$\\mathrm{1.0k}$',markersize=5.5*2)
plt.semilogx(MomentumAx015,OptConduct015,'-',c=[0.0, 1.0, .50],label='$\\mathrm{1.5k}$',markersize=5.*2)
plt.semilogx(MomentumAx020,OptConduct020,'-',c=[0.0, 1.0, .75],label='$\\mathrm{2.0k}$',markersize=4.5*2)
plt.semilogx(MomentumAx025,OptConduct025,'-',c=[0.0, 1.0, 1.0],label='$\\mathrm{2.5k}$',markersize=4.*2)
plt.semilogx(MomentumAx030,OptConduct030,'-',c=[0.0, .75, 1.0],label='$\\mathrm{3.0k}$',markersize=3.5*2)
plt.semilogx(MomentumAx035,OptConduct035,'-',c=[0.0, .50, 1.0],label='$\\mathrm{3.5k}$',markersize=3.*2)
plt.semilogx(MomentumAx040,OptConduct040,'-',c=[0.0, .25, 1.0],label='$\\mathrm{4.0k}$',markersize=2.5*2)
plt.semilogx(MomentumAx045,OptConduct045,'-',c=[0.0, 0.0, 1.0],label='$\\mathrm{4.5k}$',markersize=2.*2)
plt.semilogx(MomentumAx050,OptConduct050,'-',c=[.25, 0.0, 1.0],label='$\\mathrm{5.0k}$',markersize=1.5*2)
plt.semilogx(MomentumAx060,OptConduct060,'-',c=[.50, 0.0, 1.0],label='$\\mathrm{6.0k}$',markersize=1.*2)
#plt.semilogx(MomentumAx070,OptConduct070,'*',c=[.75, 0.0, 1.0],label='$\\mathrm{7.0k}$')
#plt.semilogx(MomentumAx080,OptConduct080,'-',c=[1.0, 0.0, 1.0],label='$\\mathrm{8.0k}$')
#plt.semilogx(MomentumAx090,OptConduct090,'-',c=[1.0, 0.0, .75],label='$\\mathrm{9.0k}$')
#plt.semilogx(MomentumAx100,OptConduct100,'-',c=[1.0, 0.0, .50],label='$\\mathrm{10k}$')

#plt.semilogx(MomentumAxInf,OptConductInf,'-',c=[0.0, 0.0, 0.0],label='$\\mathrm{\infty}$')



plt.semilogx(MomentumAx100,ReferenceM,'-',c=[0.0, 0.0, 0.0])
plt.semilogx(MomentumAx100,Reference0,'-',c=[0.0, 0.0, 0.0])
plt.semilogx(MomentumAx100,ReferenceP,'-',c=[0.0, 0.0, 0.0])

#plt.legend(['data', 'linear', 'cubic','spline'], loc='best')
plt.xlim(1e-5-1e-6,1e+0)
#NumberAlpha = 40
NumberAlpha = 2

plt.ylim(NumberAlpha*(19-6*np.pi)/12*Parameters[1]     -NumberAlpha*(19-6*np.pi)/12*Parameters[1],+(19-6*np.pi)/12*Parameters[1]*1)
plt.legend(bbox_to_anchor=(1, 1), loc=2, borderaxespad=0.)
#plt.suptitle('$\\tan^{2}(\\theta),\\quad d_{IR}/d_{UV}=100$' ,fontsize=20, fontname='Times New Roman')
plt.show()

