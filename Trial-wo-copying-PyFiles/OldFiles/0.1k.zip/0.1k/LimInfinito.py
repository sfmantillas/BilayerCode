import numpy as np
import matplotlib.pyplot as plt
import scipy.interpolate as ipl

data001 = np.genfromtxt('OC0.1k.txt')
MomentumAx001 = data001[:,][:,0]
OptConduct001 = data001[:,][:,3]

data002 = np.genfromtxt('OC0.2k.txt')
MomentumAx002 = data002[:,][:,0]
OptConduct002 = data002[:,][:,3]

data003 = np.genfromtxt('OC0.3k.txt')
MomentumAx003 = data003[:,][:,0]
OptConduct003 = data003[:,][:,3]

data004 = np.genfromtxt('OC0.4k.txt')
MomentumAx004 = data004[:,][:,0]
OptConduct004 = data004[:,][:,3]

data005 = np.genfromtxt('OC0.5k.txt')
MomentumAx005 = data005[:,][:,0]
OptConduct005 = data005[:,][:,3]

data006 = np.genfromtxt('OC0.6k.txt')
MomentumAx006 = data006[:,][:,0]
OptConduct006 = data006[:,][:,3]

data007 = np.genfromtxt('OC0.7k.txt')
MomentumAx007 = data007[:,][:,0]
OptConduct007 = data007[:,][:,3]

data008 = np.genfromtxt('OC0.8k.txt')
MomentumAx008 = data008[:,][:,0]
OptConduct008 = data008[:,][:,3]

data009 = np.genfromtxt('OC0.9k.txt')
MomentumAx009 = data009[:,][:,0]
OptConduct009 = data009[:,][:,3]

data010 = np.genfromtxt('OC1.0k.txt')
MomentumAx010 = data010[:,][:,0]
OptConduct010 = data010[:,][:,3]

data015 = np.genfromtxt('OC1.5k.txt')
MomentumAx015 = data015[:,][:,0]
OptConduct015 = data015[:,][:,3]

data020 = np.genfromtxt('OC2.0k.txt')
MomentumAx020 = data020[:,][:,0]
OptConduct020 = data020[:,][:,3]

data025 = np.genfromtxt('OC2.5k.txt')
MomentumAx025 = data025[:,][:,0]
OptConduct025 = data025[:,][:,3]

data030 = np.genfromtxt('OC3.0k.txt')
MomentumAx030 = data030[:,][:,0]
OptConduct030 = data030[:,][:,3]

data035 = np.genfromtxt('OC3.5k.txt')
MomentumAx035 = data035[:,][:,0]
OptConduct035 = data035[:,][:,3]

data040 = np.genfromtxt('OC4.0k.txt')
MomentumAx040 = data040[:,][:,0]
OptConduct040 = data040[:,][:,3]

data045 = np.genfromtxt('OC4.5k.txt')
MomentumAx045 = data045[:,][:,0]
OptConduct045 = data045[:,][:,3]

data050 = np.genfromtxt('OC5.0k.txt')
MomentumAx050 = data050[:,][:,0]
OptConduct050 = data050[:,][:,3]

data060 = np.genfromtxt('OC6.0k.txt')
MomentumAx060 = data060[:,][:,0]
OptConduct060 = data060[:,][:,3]

data070 = np.genfromtxt('OC7.0k.txt')
MomentumAx070 = data070[:,][:,0]
OptConduct070 = data070[:,][:,3]

data080 = np.genfromtxt('OC8.0k.txt')
MomentumAx080 = data080[:,][:,0]
OptConduct080 = data080[:,][:,3]

data090 = np.genfromtxt('OC9.0k.txt')
MomentumAx090 = data090[:,][:,0]
OptConduct090 = data090[:,][:,3]

data100 = np.genfromtxt('OC10k.txt')
MomentumAx100 = data100[:,][:,0]
OptConduct100 = data100[:,][:,3]

ListMomentumAx = [MomentumAx001,MomentumAx002,MomentumAx003,MomentumAx004,MomentumAx005,MomentumAx006,MomentumAx007,MomentumAx008,MomentumAx009,MomentumAx010,MomentumAx015,MomentumAx020,MomentumAx025,MomentumAx030,MomentumAx035,MomentumAx040,MomentumAx045,MomentumAx050,MomentumAx060,MomentumAx070,MomentumAx080,MomentumAx090,MomentumAx100]
ListOptConduct = [OptConduct001,OptConduct002,OptConduct003,OptConduct004,OptConduct005,OptConduct006,OptConduct007,OptConduct008,OptConduct009,OptConduct010,OptConduct015,OptConduct020,OptConduct025,OptConduct030,OptConduct035,OptConduct040,OptConduct045,OptConduct050,OptConduct060,OptConduct070,OptConduct080,OptConduct090,OptConduct100]
NameInterpolar = ["./Inf/IntOC0.1k.txt","./Inf/IntOC0.2k.txt","./Inf/IntOC0.3k.txt","./Inf/IntOC0.4k.txt","./Inf/IntOC0.5k.txt","./Inf/IntOC0.6k.txt","./Inf/IntOC0.7k.txt","./Inf/IntOC0.8k.txt","./Inf/IntOC0.9k.txt","./Inf/IntOC1.0k.txt","./Inf/IntOC1.5k.txt","./Inf/IntOC2.0k.txt","./Inf/IntOC2.5k.txt","./Inf/IntOC3.0k.txt","./Inf/IntOC3.5k.txt","./Inf/IntOC4.0k.txt","./Inf/IntOC4.5k.txt","./Inf/IntOC5.0k.txt","./Inf/IntOC6.0k.txt","./Inf/IntOC7.0k.txt","./Inf/IntOC8.0k.txt","./Inf/IntOC9.0k.txt","./Inf/IntOC10k.txt"]
NameExtrapolar = ["./Inf/ExtOC0.1k.txt","./Inf/ExtOC0.2k.txt","./Inf/ExtOC0.3k.txt","./Inf/ExtOC0.4k.txt","./Inf/ExtOC0.5k.txt","./Inf/ExtOC0.6k.txt","./Inf/ExtOC0.7k.txt","./Inf/ExtOC0.8k.txt","./Inf/ExtOC0.9k.txt","./Inf/ExtOC1.0k.txt","./Inf/ExtOC1.5k.txt","./Inf/ExtOC2.0k.txt","./Inf/ExtOC2.5k.txt","./Inf/ExtOC3.0k.txt","./Inf/ExtOC3.5k.txt","./Inf/ExtOC4.0k.txt","./Inf/ExtOC4.5k.txt","./Inf/ExtOC5.0k.txt","./Inf/ExtOC6.0k.txt","./Inf/ExtOC7.0k.txt","./Inf/ExtOC8.0k.txt","./Inf/ExtOC9.0k.txt","./Inf/ExtOC10k.txt"]
ListSizeSystem = [1.0e2,2.0e2,3.0e2,4.0e2,5.0e2,6.0e2,7.0e2,8.0e2,9.0e2,1.0e3,1.5e3,2.0e3,2.5e3,3.0e3,3.5e3,4.0e3,4.5e3,5.0e3,6.0e3,7.0e3,8.0e3,9.0e3,1.0e4]

'''
file1.write("%s" % (0)),
for m2 in range(len(MomentumAx001)/2,len(MomentumAx001)):
    file1.write("%s" % (MomentumAx001[m2])),
    file1.write("\t"),
file1.write('\n'),
'''
from scipy import optimize

def test_func(x, a, b, c, d):
    return a + b * x + c * x ** 2 + d * x ** 3

for m0 in range(0,len(ListMomentumAx)-4):
    
    file1 = open(NameInterpolar[m0],"w")
    for m1 in range(m0,len(ListMomentumAx)):
        x = ListMomentumAx[m1]
        y = ListOptConduct[m1]
        fs = ipl.splrep(ListMomentumAx[m1], ListOptConduct[m1], s=0, k=1)
        
        ynew = ipl.splev(ListMomentumAx[m0], fs, der=0)
        
        file1.write("%s" % (1./ListSizeSystem[m1])),
        file1.write("\t"),
        for m2 in range(len(ListMomentumAx[m0])/2,len(ListMomentumAx[m0])):
            file1.write("%s" % (ynew[m2])),
            file1.write("\t"),
        file1.write('\n'),
    file1.close()
    
    ######################################################################
    
    file1 = open(NameExtrapolar[m0],"w")
    
    dataN = np.genfromtxt(NameInterpolar[m0])
    
    data_x = dataN[:,][:,0]
    
    for m1 in range(0,len(ListMomentumAx[m0])/2):
        data_y = dataN[:,][:,m1+1]
        params = np.polyfit(data_x, data_y, 3)
        residuals = data_y - test_func(data_x, params[3], params[2], params[1], params[0])
        ss_res = np.sum(residuals**2)
        ss_tot = np.sum((data_y-np.mean(data_y))**2)
        r_squared = 1 - (ss_res / ss_tot)
        file1.write("%s" % (ListMomentumAx[m0][len(ListMomentumAx[m0])/2+m1])),
        file1.write("\t"),
        file1.write("%s" % (params[3]))
        file1.write("\t"),
        file1.write("%s" % (params[2]))
        file1.write("\t"),
        file1.write("%s" % (params[1]))
        file1.write("\t"),
        file1.write("%s" % (params[0]))
        file1.write("\t"),
        file1.write("%s" % (r_squared))
        file1.write("\t"),
        file1.write("%s" % (1-r_squared))
        file1.write('\n'),
    
    file1.close()
